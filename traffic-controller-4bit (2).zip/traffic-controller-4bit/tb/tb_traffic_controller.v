`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// Self-checking testbench for traffic_controller
//  * checks phase order and exact phase durations over 3 full cycles
//  * checks asynchronous reset in the middle of a phase
//  * checks safety: both roads are never non-red at the same time
// Prints "TEST PASSED" or "TEST FAILED" and writes waves to traffic.vcd
// -----------------------------------------------------------------------------
module tb_traffic_controller;

    localparam [3:0] T_GREEN  = 4'd10;
    localparam [3:0] T_YELLOW = 4'd3;

    localparam [2:0] GREEN  = 3'b001;
    localparam [2:0] YELLOW = 3'b010;
    localparam [2:0] RED    = 3'b100;

    reg        clk;
    reg        rst_n;
    wire [2:0] ns_light;
    wire [2:0] ew_light;

    integer errors;
    integer i;

    traffic_controller #(
        .T_GREEN (T_GREEN),
        .T_YELLOW(T_YELLOW)
    ) dut (
        .clk     (clk),
        .rst_n   (rst_n),
        .ns_light(ns_light),
        .ew_light(ew_light)
    );

    // 100 MHz clock
    initial clk = 1'b0;
    always #5 clk = ~clk;

    // Waveform dump
    initial begin
        $dumpfile("traffic.vcd");
        $dumpvars(0, tb_traffic_controller);
    end

    // Safety monitor: never both roads green/yellow at the same time
    always @(posedge clk) begin
        if (rst_n && (|(ns_light[1:0])) && (|(ew_light[1:0]))) begin
            errors = errors + 1;
            $display("[%0t] ERROR: both roads active  NS=%b EW=%b",
                     $time, ns_light, ew_light);
        end
    end

    // Check that lights hold the expected pattern for 'len' clock cycles.
    // Samples on the falling clock edge.
    task check_phase;
        input [2:0]  exp_ns;
        input [2:0]  exp_ew;
        input integer len;
        integer k;
        begin
            for (k = 0; k < len; k = k + 1) begin
                if (ns_light !== exp_ns || ew_light !== exp_ew) begin
                    errors = errors + 1;
                    $display("[%0t] ERROR: cycle %0d/%0d exp NS=%b EW=%b, got NS=%b EW=%b",
                             $time, k + 1, len, exp_ns, exp_ew, ns_light, ew_light);
                end
                @(negedge clk);
            end
        end
    endtask

    initial begin
        errors = 0;
        rst_n  = 1'b0;
        #22;
        @(negedge clk);
        rst_n = 1'b1;           // release reset on a falling edge

        // Three complete traffic cycles
        for (i = 0; i < 3; i = i + 1) begin
            check_phase(GREEN,  RED,    T_GREEN);
            check_phase(YELLOW, RED,    T_YELLOW);
            check_phase(RED,    GREEN,  T_GREEN);
            check_phase(RED,    YELLOW, T_YELLOW);
        end

        // Asynchronous reset in the middle of the EW green phase
        check_phase(GREEN,  RED,    T_GREEN);
        check_phase(YELLOW, RED,    T_YELLOW);
        check_phase(RED,    GREEN,  4);
        #3 rst_n = 1'b0;
        #1;
        if (ns_light !== GREEN || ew_light !== RED) begin
            errors = errors + 1;
            $display("[%0t] ERROR: async reset did not return to NS green", $time);
        end
        @(negedge clk);
        rst_n = 1'b1;

        // Must restart a full cycle from NS green
        check_phase(GREEN,  RED,    T_GREEN);
        check_phase(YELLOW, RED,    T_YELLOW);
        check_phase(RED,    GREEN,  T_GREEN);
        check_phase(RED,    YELLOW, T_YELLOW);

        if (errors == 0) $display("TEST PASSED");
        else             $display("TEST FAILED: %0d error(s)", errors);
        $finish;
    end

    // Watchdog
    initial begin
        #100000;
        $display("TEST FAILED: timeout");
        $finish;
    end

endmodule
