// -----------------------------------------------------------------------------
// 4-bit Traffic Light Controller
//
// Two-road intersection (North-South / East-West) controlled by a Moore FSM
// and a 4-bit timer. Each light phase lasts a programmable number of clock
// cycles (1..15), since the timer is 4 bits wide.
//
// Light encoding (one-hot, {RED, YELLOW, GREEN}):
//   GREEN  = 3'b001
//   YELLOW = 3'b010
//   RED    = 3'b100
//
// State sequence:
//   S_NS_GREEN -> S_NS_YELLOW -> S_EW_GREEN -> S_EW_YELLOW -> (repeat)
// -----------------------------------------------------------------------------
module traffic_controller #(
    parameter [3:0] T_GREEN  = 4'd10,  // green phase length  (clock cycles)
    parameter [3:0] T_YELLOW = 4'd3    // yellow phase length (clock cycles)
)(
    input  wire       clk,       // system clock
    input  wire       rst_n,     // asynchronous active-low reset
    output reg  [2:0] ns_light,  // North-South light {R,Y,G}
    output reg  [2:0] ew_light   // East-West   light {R,Y,G}
);

    // Light encodings
    localparam [2:0] GREEN  = 3'b001;
    localparam [2:0] YELLOW = 3'b010;
    localparam [2:0] RED    = 3'b100;

    // FSM state encodings
    localparam [1:0] S_NS_GREEN  = 2'd0;
    localparam [1:0] S_NS_YELLOW = 2'd1;
    localparam [1:0] S_EW_GREEN  = 2'd2;
    localparam [1:0] S_EW_YELLOW = 2'd3;

    reg [1:0] state;   // current phase
    reg [3:0] count;   // 4-bit phase timer

    // Length of the current phase
    wire is_green_phase = (state == S_NS_GREEN) || (state == S_EW_GREEN);
    wire [3:0] limit    = is_green_phase ? T_GREEN : T_YELLOW;

    // Phase ends on the last cycle of the programmed duration
    wire expired = (count == (limit - 4'd1));

    // State + timer register
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= S_NS_GREEN;
            count <= 4'd0;
        end else if (expired) begin
            state <= state + 2'd1;   // wraps 3 -> 0
            count <= 4'd0;
        end else begin
            count <= count + 4'd1;
        end
    end

    // Moore outputs (depend on state only)
    always @(*) begin
        case (state)
            S_NS_GREEN:  begin ns_light = GREEN;  ew_light = RED;    end
            S_NS_YELLOW: begin ns_light = YELLOW; ew_light = RED;    end
            S_EW_GREEN:  begin ns_light = RED;    ew_light = GREEN;  end
            S_EW_YELLOW: begin ns_light = RED;    ew_light = YELLOW; end
            default:     begin ns_light = RED;    ew_light = RED;    end
        endcase
    end

endmodule
