# 4-bit Traffic Light Controller (Verilog)

A two-road (North-South / East-West) traffic light controller written in Verilog.
A Moore FSM sequences the phases and a **4-bit timer** sets each phase length
(1 to 15 clock cycles).

## Features
- 4-state Moore FSM, 4-bit phase counter
- Programmable green / yellow durations via parameters (`T_GREEN`, `T_YELLOW`)
- Asynchronous active-low reset
- Self-checking testbench with waveform dump
- GitHub Actions workflow that runs the simulation on every push

## Ports

| Port       | Dir | Width | Description                          |
|------------|-----|-------|--------------------------------------|
| `clk`      | in  | 1     | System clock                         |
| `rst_n`    | in  | 1     | Async active-low reset               |
| `ns_light` | out | 3     | North-South light `{R, Y, G}`        |
| `ew_light` | out | 3     | East-West light `{R, Y, G}`          |

Light encoding: `GREEN = 001`, `YELLOW = 010`, `RED = 100`.

## State machine

```mermaid
stateDiagram-v2
    [*] --> NS_GREEN: reset
    NS_GREEN  --> NS_YELLOW: count == T_GREEN-1
    NS_YELLOW --> EW_GREEN:  count == T_YELLOW-1
    EW_GREEN  --> EW_YELLOW: count == T_GREEN-1
    EW_YELLOW --> NS_GREEN:  count == T_YELLOW-1
```

| State       | NS     | EW     | Duration   |
|-------------|--------|--------|------------|
| NS_GREEN    | Green  | Red    | `T_GREEN`  |
| NS_YELLOW   | Yellow | Red    | `T_YELLOW` |
| EW_GREEN    | Red    | Green  | `T_GREEN`  |
| EW_YELLOW   | Red    | Yellow | `T_YELLOW` |

## Project structure

```
.
├── rtl/traffic_controller.v        # design
├── tb/tb_traffic_controller.v      # self-checking testbench
├── Makefile
└── .github/workflows/sim.yml       # CI
```

## Run the simulation

Requires [Icarus Verilog](https://steveicarus.github.io/iverilog/) (and optionally GTKWave).

```bash
make run     # compile + simulate, prints TEST PASSED / TEST FAILED
make wave    # open traffic.vcd in GTKWave
make clean
```

## What the testbench checks
1. Correct phase order and exact phase durations over 3 full cycles
2. Asynchronous reset in the middle of a phase returns to NS green
3. Safety: both roads are never green/yellow at the same time

## Possible extensions
- Pedestrian crossing request input
- Vehicle sensor for a side road
- Seven-segment countdown display driven by the 4-bit counter
- FPGA implementation with a clock divider for a 1 Hz tick

## License
MIT
